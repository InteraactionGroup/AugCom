import { Component, OnInit } from '@angular/core';
import { BarcontentService } from '../barcontent.service';
import { Bouton  } from '../cell';
@Component({
  selector: 'app-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.css']
})
export class BarComponent implements OnInit {

  constructor(private barService: BarcontentService) {}

  ngOnInit() {
  }
getBar(): Bouton[]{
    return this.barService.boxesInBar
   }
  add(b: Bouton): void {
    this.barService.boxesInBar.concat(b);
  }
}
