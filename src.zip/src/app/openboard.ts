import { Bouton, Image, Grille  } from './cell';

export class OpenBoard {
boutons: Bouton[];
images: Image[];
grille: Grille;
}
