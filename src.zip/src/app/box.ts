export class Box {
  parent: string;
  id: string;
  name: string;
  type: string;
}