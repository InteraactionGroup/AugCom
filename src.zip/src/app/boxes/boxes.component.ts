import { Component, OnInit } from '@angular/core';
import { OpenBoard } from '../openboard';
import { Bouton } from '../cell';
import { Board } from '../mockOpenBoard';
import { BarComponent } from '../bar/bar.component';
import { BarcontentService } from '../barcontent.service';
import { getSymbolIterator } from '@angular/core/src/util';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-boxes',
  templateUrl: './boxes.component.html',
  styleUrls: ['./boxes.component.css']
})

export class BoxesComponent implements OnInit {

  boxes = Board.boutons;
  selectedBox: Bouton = null;
  prevselectedBox: Bouton = null;
  folder = 'root';

  constructor(private barService: BarcontentService, private sanitizer: DomSanitizer) {
  }

  ngOnInit() {
  }
   getBar(): Bouton[] {
    return this.barService.boxesInBar;
   }

  onSelect(box: Bouton): void {
   this.prevselectedBox = this.selectedBox;
   this.selectedBox = box;
   this.barService.add(this.selectedBox);
  }

  onSelectFolder(box: Bouton): void {
   this.prevselectedBox = this.selectedBox;
   this.selectedBox = box;
   this.folder = box.id;
  }

  getImgUrl(box: Bouton): string {
    const s = Board.images.find(x => x.id === box.imageId).path;
    return 'url('+s+')';
  }

  public getSantizeUrl(box: Bouton) {
    const s = 'url(' + '"' + this.getImgUrl(box) + '"' + ')';
    return s; // this.sanitizer.bypassSecurityTrustUrl(s);
    // [ngStyle]="{'background': this.getSantizeUrl(box) }"
}


  onSelectBack(): void {
    this.folder = this.boxes.find(x => x.id === this.folder).extCboardLabelKey;
  }
}
